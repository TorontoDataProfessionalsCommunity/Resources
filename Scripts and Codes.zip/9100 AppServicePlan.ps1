﻿# --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE
# --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE
# --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE


# The file extension should be *.azcli, but it can be used in Powershell ISE
# In this code you must login using Azure CLI


#--- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#Framework:	Nik - Shahriar Nikkhah		Date: 2019-10-14	Time: 20:46
#Authour:	Nik - Shahriar Nikkhah		Date: 2021-04-10	Time: 22:21
#
#Name :
#Input :
#
#Output :
#How to call/use :
#
#Powershell ISE : 
#
#Description:
#
#For the next section please add : Your name , Date , what was modified or added
#Add reference number or reference an emails subject.
#
#Last Modification :
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#  This script is intended only as a supplement to demos and lectures
#  given by "Nik - Shahriar Nikkhah"
#  
#  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
#  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
#  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, NON-INFRINGMENT AND/OR FITNESS FOR A
#  PARTICULAR PURPOSE.
#--- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

# Clean Screen
CLS

####################################################################################
#  Primary Input Parameters/Settings
####################################################################################
$SubscriptionName  = 'Pay-as-you-go Subscription'
$ResourceGroupName = 'IoTC2CDataMigration_RG'
$Location          = 'westus2'

$AppservicePlan    = 'Mytest_AASP'
# Allowed values: F1 (FREE), D1 (SHARED), B1, B2, B3, I1, I2, I3, P1V2, P2V2, P3V2, PC2, PC3, PC4, S1, S2, S3.  Default: B1.
$SkuName           = 'P1V2'  

#Please first check 
# https://docs.microsoft.com/en-us/azure/app-service/overview-hosting-plans
# https://azure.microsoft.com/en-ca/pricing/details/app-service/windows/
# https://docs.microsoft.com/en-us/azure/architecture/framework/

# Small  (2 CPU core ,  8 Gib of memory)
# Medium (4 CPU cores, 16 Gib of memory)
# Large  (8 CPU cores, 32 Gib of memory) 

#DEV Test:
#    F1(Free)                          $   0.00 CAD/Month
#    D1(Shared)                        $  12.15 CAD/Month
#    B1(Basic Small)                   $  70.08 CAD/Month
#    B2(Basic Medium)                  $  ??.?? CAD/Month
#    B3(Basic Large)                   $  ??.?? CAD/Month
#
#Production
#   Recomended Pricing
#       P1V2(Premium V2 Small)         $ 186.88 CAD/Month
#       P2V2(Premium V2 Medium)        $ 373.76 CAD/Month
#       P3V2(Premium V2 Large),        $ 747.52 CAD/Month
#       PC2(Premium Container Small)   $ 308.35 CAD/Month
#       PC3(Premium Container Medium)  $ 616.70 CAD/Month
#       PC4(Premium Container Large)   $1233.41 CAD/Month
#   
#   Additional Pricing tiers
#       S1(Standard Small)             $  93.44 CAD/Month
#       S2(Standard Medium)            $ 186.88 CAD/Month
#       S3(Standard Large)             $ 373.76 CAD/Month
#       P1(Premium Small)              $ 280.32 CAD/Month
#       P2(Premium Medium)             $ 560.64 CAD/Month
#       P3(Premium Large)              $1121.28 CAD/Month
#   
#Isolated:
#    I1(Isolated Small)                $ 373.76 CAD/Month
#    I2(Isolated Medium)               $ 747.52 CAD/Month
#    I3(Isolated Large)                $1495.04 CAD/Month

####################################################################################
# Set Active Subscription
####################################################################################
#--- Set to Active Subscription
az account set --subscription $SubscriptionName

####################################################################################
# Create Object/Service 
####################################################################################
#az appservice --help
#az appservice plan --help
#az appservice plan create --help

#Check if service does not exists, then create the service
$planCheck = $(az appservice plan list --resource-group $ResourceGroupName --query "[?name=='$AppservicePlan']" --output json)
$planExists = $planCheck.Length -gt 3
if (!$planExists) {
    az appservice plan create --name $AppservicePlan `
                              --resource-group $ResourceGroupName `
                              --location $Location `
                              --sku $SkuName `
                              --no-wait
}

####################################################################################
# Check if the object/service was created
####################################################################################
#az appservice plan list --help
#az appservice plan list --output table
#az appservice plan list --resource-group $ResourceGroupName --output table
cls
$query  = '[].{Location:location, ResourceGroup:resourceGroup,Name:name, NumberOfSites:numberOfSites, Tier:sku.tier, SKUName:sku.name , SKUSize:sku.size ,tier:tier }'
az appservice plan list --query $query --output table
az appservice plan list --resource-group $ResourceGroupName --query $query --output table

#az appservice plan show --help
az appservice plan show --name $AppservicePlan --resource-group $ResourceGroupName --subscription $SubscriptionName

####################################################################################
# Clean up everything
####################################################################################
#az group delete --resource-group $ResourceGroupName --subscription $SubscriptionName --yes --no-wait
#az appservice plan delete --help
#az appservice plan delete --name $AppservicePlan --resource-group $ResourceGroupName --subscription $SubscriptionName --yes

####################################################################################
# Other
####################################################################################
# Avoid showing your Azure credential guids
#CLS