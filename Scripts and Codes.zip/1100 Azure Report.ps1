﻿# --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE
# --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE
# --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE --- THIS IS A AZURE CLI CODE


# The file extension should be *.azcli, but it can be used in Powershell ISE
# In this code you must login using Azure CLI


#--- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#Framework:	Nik - Shahriar Nikkhah		Date: 2019-10-14	Time: 20:46
#Authour:	Nik - Shahriar Nikkhah		Date: 2021-04-14	Time: 23:36
#
#Name :
#Input :
#
#Output :
#How to call/use :
#
#Powershell ISE : 
#
#Description:
#
#For the next section please add : Your name , Date , what was modified or added
#Add reference number or reference an emails subject.
#
#Last Modification :
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#  This script is intended only as a supplement to demos and lectures
#  given by "Nik - Shahriar Nikkhah"
#  
#  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
#  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
#  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, NON-INFRINGMENT AND/OR FITNESS FOR A
#  PARTICULAR PURPOSE.
#--- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

####################################################################################
#  Login 
####################################################################################
#az --help
#az Login --help
#az Login
# Clean Screen
CLS

####################################################################################
#  Primary Input Parameters/Settings
####################################################################################
$SubscriptionName  = 'Pay As You Go'
#$ResourceGroupName = 'IoTC2CDataMigration_RG'
$CSVFileLocation   = 'C:\Users\snikk\Google Drive\IoTCoast2Coast\2021\Projects 2\2021-04-14 AzureReport'

####################################################################################
# Set Active Subscription
####################################################################################
#======= Accounts
#az account --help
#--- Set to Active Subscription
az account set --subscription $SubscriptionName

#az account list --help
#az account list

#======= Resource Group
#az group --help
#az group list --help
$query  = 'sort_by([].{Location:location, Name:name, Type:type, Tags:tags}, &Location)'
#az group list --output table --query $query 
$Results = (az group list --query $query --output json | convertfrom-json)
$Results | Export-Csv $CSVFileLocation'\010 - ResourceGroup.csv' -NoTypeInformation


#======= Resources
#az resource --help
#az resource list --help
$query  = '[].{ResourceGroup:resourceGroup, Location:location, Name:name, SKUName:sku.name, SKUTier:sku.tier, Type:type}'
#az resource list --output table --query $query 
$Results = (az resource list --query $query --output json | convertfrom-json)
$Results | Export-Csv $CSVFileLocation'\020 - Resources.csv' -NoTypeInformation


#======= Azure Blob Storage
#az storage --help
#az storage account list --help
$query  = '[].{ResourceGroup:resourceGroup, Location:location, Name:name, AccessTier:accessTier, Kind:kind, SKUName:sku.name, SKUTier:sku.tier, Type:type}'
#az storage account list --output table --query $query 
$Results = (az storage account list --query $query --output json | convertfrom-json)
$Results | Export-Csv $CSVFileLocation'\030 - StorageAccount.csv' -NoTypeInformation


#======= Azure SQL Server
#az sql --help
#az sql server list --help
$query  = '[].{ResourceGroup:resourceGroup, Location:location, Name:name, FullyQualifiedDomainName:fullyQualifiedDomainName, AdministratorLogin:administratorLogin, PublicNetworkAccess:publicNetworkAccess, Type:type}'
#az sql server list --output table --query $query 
$Results = (az sql server list --query $query --output json | convertfrom-json)
$Results | Export-Csv $CSVFileLocation'\040 - AzureSQLServer.csv' -NoTypeInformation

#======= SQL Server DB
#az sql --help
#az sql db list --help

#az sql db list --resource-group IoTC2CDataMigration_RG --server iotc2cdatamigration-asqlsrv

$query  = '[].{ResourceGroup:resourceGroup, Location:location, Name:name, FullyQualifiedDomainName:fullyQualifiedDomainName, AdministratorLogin:administratorLogin, PublicNetworkAccess:publicNetworkAccess, Type:type}'
#az sql db list --output table --query $query 
$Results = (az sql db list --query $query --output json | convertfrom-json)
$Results | Export-Csv $CSVFileLocation'\043 - SQLServerDB.csv' -NoTypeInformation

